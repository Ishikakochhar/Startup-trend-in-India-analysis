sunp <- read.csv("C:/Users/rishi/OneDrive/Desktop/Study material/MFE-2/Final/SPFINAL.csv")
sunp
par(mfrow=c(2,2))
plot(y=sunp$DE.RATIO,x=data$YEAR,type='l',col='green',lwd='2',xlab='Years',ylab='D/E Ratio',main='SUNPHARMA D/E Ratio')
plot(y=sunp$PE.RATIO,x=data$YEAR,type='l',col='blue',lwd='2',xlab='Years',ylab='P/E Ratio',main='SUNPHARMA P/E Ratio')
plot(y=sunp$Dividend,x=ONGC$YEAR,type='l',col='red',lwd='2',xlab='Years',ylab='Divend/share',main='SUNPHARMA Dividend/Share')
plot(y=sunp$ROA,x=ONGC$YEAR,type='l',col='purple',lwd='2',xlab='Years',ylab='ROA',main='SUNPHARMA Return on Assets')

