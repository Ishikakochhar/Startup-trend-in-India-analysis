ONGC <- read.csv("C:/Users/rishi/OneDrive/Desktop/Study material/MFE-2/Final/OGNCFINAL.csv")
ONGC
par(mfrow=c(2,2))
plot(y=ONGC$DE.RATIO,x=ONGC$YEAR,type='l',col='green',lwd='2',xlab='Years',ylab='D/E Ratio',main='ONGC D/E Ratio')
plot(y=ONGC$PE.RATIO,x=ONGC$YEAR,type='l',col='blue',lwd='2',xlab='Years',ylab='P/E Ratio',main='ONGC P/E Ratio')
plot(y=ONGC$Dividend,x=ONGC$YEAR,type='l',col='red',lwd='2',xlab='Years',ylab='Divend/share',main='ONGC Dividend/Share')
plot(y=ONGC$ROA,x=ONGC$YEAR,type='l',col='purple',lwd='2',xlab='Years',ylab='ROA',main='ONGC Return on Assets')

