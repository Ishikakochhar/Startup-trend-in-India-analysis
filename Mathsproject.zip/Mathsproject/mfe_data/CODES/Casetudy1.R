library(tidyverse)

bpcl <- read.csv("C:/Users/rishi/OneDrive/Desktop/BPCL.csv")

par(mfrow=c(2,2))

Close <- as.numeric(bpcl$Close)
bpcl$Date <- as.Date(bpcl$Date)

class(Close)
x <- Close
class(lag(Close))
y <- lag(Close)


bpcl <- bpcl %>%
  arrange(Date) %>%
  mutate(DailyReturn = ((x - y) / y))


nullhypo <- "The average daily returns are zero."
Althypo <- "The average daily returns are different from zero."


alpha <- 0.05
t_test <- t.test(bpcl$DailyReturn, mu = 0)

test_statistic <- t_test$statistic
p_value <- t_test$p.value

ggplot(bpcl, aes(x = Date, y = DailyReturn)) +
  geom_line() +
  labs(title = "Daily Returns",
       x = "Date",
       y = "Daily Return") +
  theme_minimal()


if (p_value < alpha) {
  p_value_label <- paste("p-value =", round(p_value, 4), "<", "alpha =", alpha)
} else {
  p_value_label <- paste("p-value =", round(p_value, 4), ">=", "alpha =", alpha)
}

plot_text <- paste(nullhypo, "\n", Althypo, "\n", p_value_label)

ggplot(bpcl, lwd=2,col='red', aes(x = Date, y = DailyReturn)) +  geom_line() +
  labs(title = "Daily Returns",
       x = "Date",
       y = "Daily Return") +
  theme_minimal() +
  annotate("text", x = min(bpcl$Date), y = max(bpcl$DailyReturn),
           label = plot_text, hjust = 0, vjust = 1, parse = TRUE)

if (p_value < alpha) {
  conclusion <- "Reject the null hypothesis. There is evidence of a significant difference."
} else {
  conclusion <- "Fail to reject the null hypothesis. There is insufficient evidence to conclude a significant difference."
}

cat("Hypothesis Test Results\n"
    ,"Null Hypothesis:", nullhypo, "\n"
    ,"Alternative Hypothesis:", Althypo, "\n"
    ,"Significance Level (alpha):", alpha, "\n"
    ,"Test Statistic:", test_statistic, "\n"
    ,"p-value:", p_value, "\n"
    ,"Conclusion:", conclusion, "\n")

ggplot(bpcl, aes(x = 1, y = DailyReturn)) +
  geom_boxplot() +
  labs(title = "Boxplot of Daily Returns",
       x = "",
       y = "Daily Return") +
  theme_minimal()

ggplot(stock_data, aes(x = DailyReturn)) +
  geom_histogram(binwidth = 0.01, fill = "cyan", color = "black") +
  labs(title = "Histogram of Daily Returns",
       x = "Daily Return",
       y = "Frequency") +
  theme_minimal()

ggplot(stock_data, aes(x = DailyReturn)) +
  geom_density(fill = "mediumpurple1", color = "black") +
  labs(title = "Density Plot of Daily Returns",
       x = "Daily Return",
       y = "Density") +
  theme_minimal()

ggplot(stock_data, aes(x = Date, y = Close)) +
  geom_line() +
  labs(title = "Time Series Plot of Closing Prices",
       x = "Date",
       y = "Closing Price") +
  theme_minimal()




