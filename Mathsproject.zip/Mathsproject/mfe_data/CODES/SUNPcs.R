library(plotly)
df <- read.csv("C:/Users/rishi/OneDrive/Desktop/SUNP.csv")
plot_ly(df, type = "candlestick", x = ~Date, open = ~Open, high = ~High, low = ~Low, close = ~Close) %>%
  layout(title = "Sunpharma", yaxis = list(title = "Price"), xaxis = list(title = "Date"))

