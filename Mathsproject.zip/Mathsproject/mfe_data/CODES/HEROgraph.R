hero <- read.csv("C:/Users/rishi/OneDrive/Desktop/Study material/MFE-2/Final/HMFINAL.csv")
hero
par(mfrow=c(2,2))
plot(y=hero$DE.RATIO,x=data$YEAR,type='l',col='green',lwd='2',xlab='Years',ylab='D/E Ratio',main='HEROMOTOR D/E Ratio')
plot(y=hero$PE.RATIO,x=data$YEAR,type='l',col='blue',lwd='2',xlab='Years',ylab='P/E Ratio',main='HEROMOTOR P/E Ratio')
plot(y=hero$Dividend,x=ONGC$YEAR,type='l',col='red',lwd='2',xlab='Years',ylab='Divend/share',main='HEROMOTOR Dividend/Share')
plot(y=hero$ROA,x=ONGC$YEAR,type='l',col='purple',lwd='2',xlab='Years',ylab='ROA',main='HEROMOTOR Return on Assets')


