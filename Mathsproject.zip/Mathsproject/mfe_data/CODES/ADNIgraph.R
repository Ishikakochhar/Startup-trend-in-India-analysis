adani <- read.csv("C:/Users/rishi/OneDrive/Desktop/Study material/MFE-2/Final/ADFINAL.csv")
adani
par(mfrow=c(2,2))
plot(y=adani$DE,x=data$YEAR,type='l',col='green',lwd='2',xlab='Years',ylab='D/E Ratio',main='ADANI PORTS D/E Ratio')
plot(y=adani$PE,x=data$YEAR,type='l',col='blue',lwd='2',xlab='Years',ylab='P/E Ratio',main='ADANI PORTS P/E Ratio')
plot(y=adani$Dividend,x=ONGC$YEAR,type='l',col='red',lwd='2',xlab='Years',ylab='Divend/share',main='ADANI Dividend/Share')
plot(y=adani$ROA,x=ONGC$YEAR,type='l',col='purple',lwd='2',xlab='Years',ylab='ROA',main='ADANI Return on Assets')

