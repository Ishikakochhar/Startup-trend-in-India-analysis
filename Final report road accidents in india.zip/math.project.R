install.packages("readxl")
library(readxl)

# Load the Excel file into R
df <- read_excel("C:/Users/Daksh/Desktop/GROUP-R/RA_2009.xlsx",sheet = 1)

# View the loaded data
df



library(ggplot2)

accidents <- data.frame(State = df$State, 
                        DrunkenDrivingAccidents = df$`Drunken Driving /Consumption of alcohol & drug  Total Accidents`)

ggplot(data = accidents, aes(x = State, y = DrunkenDrivingAccidents)) + 
  geom_line(color = "red") + 
  ggtitle("Total Accidents Due to Drunken Driving or Consumption of Alcohol and Drugs by State") +
  xlab("State") + ylab("Number of Accidents")







# calculate total number of accidents caused by overspeeding for each state
over_speeding_data <- df[, c("State", "Over - Speeding	Total Accidents")]
over_speeding_data <- over_speeding_data[!is.na(over_speeding_data$`Over - Speeding	Total Accidents`),]
over_speeding_data <- over_speeding_data[order(-over_speeding_data$`Over - Speeding	Total Accidents`),]
over_speeding_data$percent <- round(100*over_speeding_data$`Over - Speeding	Total Accidents`/sum(over_speeding_data$`Over - Speeding\tTotal Accidents`), 1)

# create pie chart
library(ggplot2)
ggplot(over_speeding_data, aes(x = "", y = `Over - Speeding\tTotal Accidents`, fill = State)) + 
  geom_bar(stat = "identity", width = 1) + 
  coord_polar(theta = "y") + 
  labs(title = "Total Accidents Caused by Overspeeding by State") + 
  scale_fill_hue(name = "State") + 
  geom_text(aes(label = paste(percent, "%")), position = position_stack(vjust = 0.5))




ggplot(df, aes(x="", y=`Drunken Driving /Consumption of alcohol & drug  Total Accidents`, fill=State)) + 
  geom_bar(stat="identity", width=1) +
  coord_polar("y", start=0) +
  labs(title = "Drunken Driving /Consumption of alcohol & drug  Total Accidents by State") +
  theme_void() +
  theme(plot.title = element_text(hjust = 0.5))



correlation <- cor(df$`Drunken Driving /Consumption of alcohol & drug...3`, df$`Over - Speeding...6`)

