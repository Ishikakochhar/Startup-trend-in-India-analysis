library(ggplot2)
library(dplyr)
library(tidyverse)
library(stats)

df <- read.csv("/home/linux/Desktop/R stuff/vgsales.csv")
df


df[is.na(df)] <- 0
df <- unique(df)
df$Year <- as.Date(paste(df$Year, "-01-01", sep=""), format="%Y-%m-%d")
df$Year <- format(df$Year, "%Y")
platform_categories <- c('2600' = 'Other',
                         '3DO' = 'Other',
                         '3DS' = 'Nintendo',
                         'DC' = 'Other',
                         'DS' = 'Nintendo',
                         'GB' = 'Nintendo',
                         'GBA' = 'Nintendo',
                         'GC' = 'Nintendo',
                         'GEN' = 'Other',
                         'GG' = 'Other',
                         'N64' = 'Nintendo',
                         'NES' = 'Nintendo',
                         'NG' = 'Other',
                         'PC' = 'PC',
                         'PCFX' = 'Other',
                         'PS' = 'PlayStation',
                         'PS2' = 'PlayStation',
                         'PS3' = 'PlayStation',
                         'PS4' = 'PlayStation',
                         'PSP' = 'PlayStation',
                         'PSV' = 'PlayStation',
                         'SAT' = 'Other',
                         'SCD' = 'Other',
                         'SNES' = 'Nintendo',
                         'TG16' = 'Other',
                         'WS' = 'Other',
                         'Wii' = 'Nintendo',
                         'WiiU' = 'Nintendo',
                         'X360' = 'Xbox',
                         'XB' = 'Xbox',
                         'XOne' = 'Xbox')
df$Platform_Category <- platform_categories[match(df$Platform, names(platform_categories))]
df$Publisher <- gsub(" ", "_", df$Publisher)


top_publishers <- head(sort(table(df$Publisher), decreasing = TRUE), 6)
top_publishers_df <- data.frame(Publisher = names(top_publishers),Sales = as.numeric(top_publishers))
ggplot(top_publishers_df, aes(x = Publisher, y = Sales, fill=Publisher)) +
  geom_bar(stat = "identity", fill = "gray") +
  ggtitle("Top 6 Video Game Publishers by Sales") +
  xlab("Publisher") +
  ylab("Number of Sales") +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5)) 

yearly_sales <- aggregate(Global_Sales ~ Year, data = df, FUN = sum)
ggplot(yearly_sales, aes(x = Year, y = Global_Sales)) +
geom_line(size = 1.5, color = "blue") +
ggtitle("Video Game Sales by Year") +
xlab("Year") +
ylab("Global Sales (in millions)") +
theme_minimal()



library(ggplot2)
library(scales)

na_sales <- sum(df$NA_Sales)
eu_sales <- sum(df$EU_Sales)
jp_sales <- sum(df$JP_Sales)
other_sales <- sum(df$Other_Sales)
sales_by_region <- c(na_sales, eu_sales, jp_sales, other_sales)
region_labels <- c("North America", "Europe", "Japan", "Other")

df_sales <- data.frame(region_labels, sales_by_region)

ggplot(df_sales, aes(x="", y=sales_by_region, fill=region_labels)) +
  geom_bar(stat="identity", width=1) +
  coord_polar(theta="y") +
  scale_fill_manual(values=scales::hue_pal()(4)) +
  labs(title="Video Game Sales by Region", fill="Region") +
  theme_void()


  library(dplyr)
library(ggplot2)

grouped_df <- df %>%
  group_by(Name) %>%
  summarize(Global_Sales = sum(Global_Sales)) %>%
  arrange(desc(Global_Sales))

top_10 <- head(grouped_df, n = 10)
ggplot(top_10, aes(x = reorder(Name, Global_Sales), y = Global_Sales, fill = Name)) +
  geom_col() +
  scale_fill_manual(values = palette) +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1)) +
  labs(title = "Top 10 Highest Selling Video Games", x = "Game Title", y = "Global Sales (millions)")



  library(ggplot2)

genre_sales <- df %>%
  group_by(Genre) %>%
  summarize(Global_Sales = sum(Global_Sales)) %>%
  arrange(desc(Global_Sales))

ggplot(genre_sales, aes(x = Global_Sales, y = Genre, fill = Genre)) +
  geom_col() +
  theme_minimal() +
  labs(x = "Global Sales (in millions)", y = "Genre",
       title = "Most Popular Video Game Genres") +
  scale_fill_brewer(palette = "RdYlBu") +
  coord_flip()




library(ggplot2)

df_categories <- df %>% 
  group_by(Platform_Category) %>% 
  summarise(Global_Sales = sum(Global_Sales)) %>% 
  arrange(desc(Global_Sales))


ggplot(df_categories, aes(x = Global_Sales, y = Platform_Category, fill = Platform_Category)) +
  geom_col(show.legend = FALSE) +
  scale_fill_manual(values = colors) +
  labs(x = "Global Sales (millions)", y = "Platform Category", 
       title = "Total Global Sales by Platform Category") +
  theme_bw() +
  theme(axis.text.y = element_text(angle = 0, hjust = 0.5),
        plot.title = element_text(hjust = 0.5))




library(dplyr)
library(ggplot2)

na_sales <- df %>% 
  select(NA_Sales, Year) %>% 
  group_by(Year) %>% 
  summarize(NASales = sum(NA_Sales))

ggplot(na_sales, aes(x = Year, y = NASales)) + 
  geom_line() +
  xlab("Year") +
  ylab("North America Sales (millions)") +
  ggtitle("North American Video Game Sales over Time")



library(ggplot2)

japan_sales <- df[, c("JP_Sales", "Year")]
japan_sales <- aggregate(JP_Sales ~ Year, data = japan_sales, FUN = sum)

ggplot(data = japan_sales, aes(x = Year, y = JP_Sales)) + 
  geom_line(color = "steelblue") + 
  labs(x = "Year", y = "Japan Sales (millions)", title = "Japan Video Game Sales over Time")



library(ggplot2)

japan_sales <- df[, c("JP_Sales", "Year")]
japan_sales <- aggregate(JP_Sales ~ Year, data = japan_sales, FUN = sum)

ggplot(data = japan_sales, aes(x = Year, y = JP_Sales)) + 
  geom_line(color = "steelblue") + 
  labs(x = "Year", y = "Japan Sales (millions)", title = "Japan Video Game Sales over Time")



library(dplyr)
library(ggplot2)
top_publishers <- df %>% 
  group_by(Publisher) %>% 
  summarize(Total_Sales = sum(Global_Sales)) %>% 
  arrange(desc(Total_Sales)) %>% 
  head(5) %>% 
  pull(Publisher)
df_top_publishers <- df %>% 
  filter(Publisher %in% top_publishers) %>% 
  mutate(Genre = case_when(
    Genre == "Sports" ~ "Sport",
    Genre == "Platform" ~ "Platf.",
    Genre == "Racing" ~ "Race",
    Genre == "Role-Playing" ~ "RPG",
    Genre == "Puzzle" ~ "Puzz.",
    Genre == "Misc" ~ "Misc.",
    Genre == "Shooter" ~ "Shoot",
    Genre == "Simulation" ~ "Simul.",
    Genre == "Action" ~ "Act.",
    Genre == "Fighting" ~ "Fight",
    Genre == "Strategy" ~ "Strat.",
    Genre == "Adventure" ~ "Adv."
  ))
ggplot(df_top_publishers, aes(x = Genre, fill = Publisher)) +
  geom_bar(position = "dodge") +
  scale_fill_manual(values = c("#FC8D62", "#66C2A5", "#8DA0CB", "#E78AC3", "#A6D854")) +
  labs(x = "Genre", y = "Count", fill = "Publisher") +
  ggtitle("Count of each Genre by Publisher")


  library(ggplot2)

action_sales_data <- df[df$Genre == "Action",]
yearly_sales <- aggregate(Global_Sales ~ Year, data=action_sales_data, sum)
ggplot(yearly_sales, aes(x=Year, y=Global_Sales)) +
  geom_line(color="tomato", size=2) +
  labs(title="Action Genre Sales by Year", x="Year", y="Global Sales (in millions)") +
  theme_bw()


  library(ggplot2)

shooter_sales_data <- df[df$Genre == "Shooter", ]
yearly_sales <- aggregate(Global_Sales ~ Year, data = shooter_sales_data, sum)

ggplot(yearly_sales, aes(x = Year, y = Global_Sales)) +
  geom_line() +
  ggtitle("Shooter Genre Sales by Year") +
  xlab("Year") +
  ylab("Global Sales (in millions)")



library(ggplot2)
sports_sales_data <- df[df$Genre == "Sports",]
yearly_sales <- aggregate(Global_Sales ~ Year, data=sports_sales_data, sum)
ggplot(data=yearly_sales, aes(x=Year, y=Global_Sales)) + 
  geom_line() + 
  labs(title="Sports Genre Sales by Year", x="Year", y="Global Sales (in millions)") 



sales_by_year <- aggregate(Global_Sales ~ Year, data = df, sum)
plot(sales_by_year$Year, sales_by_year$Global_Sales, type = 'l', 
     xlab = 'Year', ylab = 'Global Sales (in millions)', 
     main = 'Global Video Game Sales by Year')



top5data <- df


top5 <- c("Nintendo", "Electronic Arts", "Activision", "Sony Computer Entertainment", "Ubisoft")
top5data <- subset(top5data, Publisher %in% top5)

top5dataSlice <- top5data[, c("Year", "Publisher", "Global_Sales")]

countData <- aggregate(Global_Sales ~ Year + Publisher, data = top5dataSlice, FUN = length)
countData <- reshape(countData, idvar = "Year", timevar = "Publisher", direction = "wide")
colnames(countData)[-1] <- sub("Global_Sales.", "", colnames(countData)[-1])

barplot(as.matrix(countData[-1]), 
        main = "Summary of volume of games by year by publisher", 
        xlab = "Year",
        ylab = "Count of Games",
        col = c("red", "blue", "green", "orange", "purple"),
        legend.text = c("Activision", "Electronic Arts", "Nintendo", "Sony Computer Entertainment", "Ubisoft"),
        args.legend = list(x = "topright", bty = "n"))








library(ggplot2)

genres <- unique(df$Genre)

fig <- ggplot() +
  theme(plot.title = element_text(face = "bold", size = 20, hjust = 0.5))

x <- 1
y <- 1
z <- 1

for (i in genres) {
  genreData <- df[df$Genre == i,]
  plot <- ggplot(genreData, aes(x = NA_Sales, y = EU_Sales)) + 
    geom_point(color = pal[z]) + 
    geom_smooth(method = "lm", se = FALSE, color = pal[z]) +
    ggtitle(i) + 
    theme(plot.title = element_text(size = 18, hjust = 0.5))
  
  res <- lm(EU_Sales ~ NA_Sales, data = genreData)
  r2 <- summary(res)$r.squared
  p_value <- summary(res)$coefficients[8]^2
  
  plot <- plot + 
    annotate("text", x = 0.05, y = 0.925, label = paste0("R²: ", round(r2, 2)), 
             size = 5, color = "black") +
    annotate("text", x = 0.05, y = 0.875, label = paste0("P: ", round(p_value, 2)), 
             size = 5, color = "black") +
    xlab("NA Sales") +
    ylab("EU Sales")
  
  fig <- fig + 
    annotation_custom(grob = ggplotGrob(plot), xmin = (x - 1)/4, xmax = x/4, ymin = (4 - y)/3, ymax = (4 - y + 1)/3) 
  
  x <- x + 1
  z <- z + 1
  
  if (x == 5) {
    x <- 1
    y <- y + 1
  }
}

fig <- fig + 
  labs(title = "Correlation Plots of EU/NA sales by Genre, with calculated linear regression values",
       x = "NA Sales", y = "EU Sales") + 
  theme(plot.title = element_text(face = "bold", size = 20, hjust = 0.5))
fig





platforms <- unique(df$Platform_Category)
sales_by_platform <- list()

for (p in platforms) {
  sales_by_platform[[p]] <- df[df$Platform_Category == p, 'Global_Sales']
}

f_test <- aov(unlist(sales_by_platform) ~ rep(platforms, lengths(sales_by_platform)))
f_stat <- summary(f_test)[[1]][["F value"]][1]
p_value <- summary(f_test)[[1]][["Pr(>F)"]][1]

print(paste("F-statistic:", f_stat))
print(paste("p-value:", p_value))




library(corrplot)
df$Year_of_Release <- as.numeric(as.character(df$Year_of_Release))
cols <- df[,c( 'Year_of_Release",NA_Sales', 'EU_Sales', 'JP_Sales', 'Other_Sales', 'Global_Sales', 'Critic_Score')]
corr_matrix <- cor(cols)
corr_matrix
corrplot(corr_matrix)



