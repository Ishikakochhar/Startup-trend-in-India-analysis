#LOADING THE DATASET 
bmi<-read.csv("C:/Users/medak/Downloads/BMI.csv")

#COLUMNS
names(bmi)

#FIRST FEW ENTRIES
head(bmi)

#STATISTICAL SUMMARY

#Age
summary(bmi$Age)

#Weight
summary(bmi$Weight.kg.)

#Height
summary(bmi$Height.m.)

#BMI
summary(bmi$BMI)

#BOXPLOT
boxplot(bmi$Age, main = "BOXPLOT FOR AGE", ylab="Age")
hist(bmi$Age, main = "HISTOGRAM FOR AGE", xlab="Age")

#BOXPLOT
boxplot(bmi$BMI, main = "BOXPLOT FOR BMI", ylab="BMI")

#HISTOGRAM
hist(bmi$BMI, main = "HISTOGRAM FOR BMI", xlab="BMI")

boxplot(bmi$Weight)
hist(bmi$Weight)

boxplot(bmi$Height)
hist(bmi$Height)

boxplot(bmi$BMI)
hist(bmi$BMI)


model <- glm(Gender ~ BMI + Age, data = bmi, family = binomial)
summary(model)

#Total females
sum(bmi$Gender == "0")
hist(bmi$Gender=="0")

#Total males
sum(bmi$Gender == "1")

#underweight
sum(bmi$BMI <= "18")

#normal
sum( bmi$BMI <= "24.9" & bmi$BMI > "18")

#overweight
sum(bmi$BMI > "24.9")

#Age 
sum(bmi$Age <= "20")
sum(bmi$Age > "20")

#college students
college_students<- subset(bmi, Age>16 & Age<25)
head(college_students)

#histogram
hist(college_students$BMI,xlim=c(10,35),ylim=c(0,25),main="HISTOGRAM FOR BMI(College Students)",xlab="BMI(College Student)")

#underweight
x<-sum(college_students$BMI <= "18")
x

#normal
y<-sum( college_students$BMI <= "24.9" & college_students$BMI > "18")
y

#overweight
z<-sum(college_students$BMI > "24.9")
z

#total college students
s<-sum(x,y,z)
s

#percentage of college students who are categorized as obese
(z/s)*100

#creating a subset consisting of data of males
male_data <- subset(bmi, Gender == "1")
head(male_data)

#histogram
hist(male_data$BMI, ylim=c(0,30),main="HISTOGRAM FOR BMI(MALES)",xlab="BMI(MALES)")

#boxplot 
boxplot(male_data$BMI, main="BOXPLOT FOR BMI(MALES)",xlab="BMI(MALES)")

#statistical summary
summary(male_data$BMI)

#creating a subset consisting of data of females
female_data <- subset(bmi, Gender == "0")
head(female_data)

#histogram
hist(female_data$BMI,ylim=c(0,15),xlim=c(10,35),main="HISTOGRAM FOR BMI(FEMALES)",xlab="BMI(FEMALES)")

#boxplot 
boxplot(female_data$BMI, main="BOXPLOT FOR BMI(FEMALES)",xlab="BMI(FEMALES)")

#statistical summary
summary(female_data$BMI)

#creating a subset consisting of data of pregnant females
pregnant<- subset(female_data, Pregnant=="1")
head(pregnant)

#underweight
sum(pregnant$BMI <= "18")

#normal
sum(pregnant$BMI <= "24.9" & pregnant$BMI > "18")

#overweight
sum(pregnant$BMI > "24.9")

#histogram
hist(pregnant$BMI,main="HISTOGRAM FOR BMI(PREGNANT FEMALES)",xlab="BMI(PREGNANT FEMALES)")


#creating a subset consisting of data of non-pregnant females
non_pregnant<- subset(female_data, Pregnant=="0")
head(non_pregnant)

#underweight
sum(non_pregnant$BMI <= "18")

#normal
sum(non_pregnant$BMI <= "24.9" & pregnant$BMI > "18")

#overweight
sum(non_pregnant$BMI > "24.9")

#histogram
hist(non_pregnant$BMI,xlim=c(10,35),main="HISTOGRAM FOR BMI(NON-PREGNANT FEMALES)",xlab="BMI(NON-PREGNANT FEMALES)")

#statistical summary
summary(pregnant$BMI)
summary(non_pregnant$BMI)



#Age 
X<-sum(bmi$Age <= "20")
X
#subset
below_equal_to_20<- subset(bmi, Age<="20")

#normal
Y<-sum(below_equal_to_20$BMI <= "24.9" & below_equal_to_20$BMI > "18")
Y

#PERCENTAGE of age below or equal to 20
(Y/X)*100

#obese 
Z<-sum(below_equal_to_20$BMI >24.9)
Z

#PERCENTAGE of below oe equal to 20
(Z/X)*100



#Age 
X<-sum(bmi$Age > "20")
X
#subset
above_20<- subset(bmi, Age>"20")

#normal
Y<-sum(above_20$BMI <= "24.9" & above_20$BMI > "18")
Y

#PERCENTAGE of above 20
(Y/X)*100

#obese 
Z<-sum(above_20$BMI >24.9)
Z

#PERCENTAGE of above 20
(Z/X)*100










#underweight
x<-sum(male_data$BMI <= "18")
x

#normal
y<-sum( male_data$BMI <= "24.9" & male_data$BMI > "18")
y

#overweight
z<-sum(male_data$BMI > "24.9")
z

#total males
s<-sum(x,y,z)
s

#percentage of males who are categorized as normal
(y/s)*100

#percentage of males who are categorized as obese
(z/s)*100








#underweight
x<-sum(female_data$BMI <= "18")
x

#normal
y<-sum( female_data$BMI <= "24.9" & female_data$BMI > "18")
y

#overweight
z<-sum(female_data$BMI > "24.9")
z

#total females
s<-sum(x,y,z)
s

#percentage of females who are categorized as normal
(y/s)*100

#percentage of females who are categorized as obese
(z/s)*100


#underweight
x<-sum(pregnant$BMI <= "18")
x

#normal
y<-sum( pregnant$BMI <= "24.9" & pregnant$BMI > "18")
y

#overweight
z<-sum(pregnant$BMI > "24.9")
z

#total pregnant females
s<-sum(x,y,z)
s

#percentage of pregnant females who are categorized as normal
(y/s)*100










#underweight
x<-sum(non_pregnant$BMI <= "18")
x

#normal
y<-sum( non_pregnant$BMI <= "24.9" & non_pregnant$BMI > "18")
y

#overweight
z<-sum(non_pregnant$BMI > "24.9")
z

#total non-pregnant females
s<-sum(x,y,z)
s

#percentage of non-pregnant females who are categorized as normal
(y/s)*100




#creating a subset of those who don't exercise
no_exercise <- subset(bmi, Exercise.regularly.. == "0")

#underweight
x<-sum(no_exercise$BMI <= "18")
x

#normal
y<-sum( no_exercise$BMI <= "24.9" & no_exercise$BMI > "18")
y

#overweight
z<-sum(no_exercise$BMI > "24.9")
z


#total candidates who don't exercise at all
s<-sum(x,y,z)
s

#percentage of those who don't exercise and are categorized as normal
(y/s)*100





#creating a subset of those who exercises regularly
exercise <- subset(bmi, Exercise.regularly.. == "1")

#underweight
x<-sum(exercise$BMI <= "18")
x

#normal
y<-sum( exercise$BMI <= "24.9" & exercise$BMI > "18")
y

#overweight
z<-sum(exercise$BMI > "24.9")
z


#total candidates who exercises regularly
s<-sum(x,y,z)
s

#percentage of those who exercises regularly and are categorized as normal
(y/s)*100
