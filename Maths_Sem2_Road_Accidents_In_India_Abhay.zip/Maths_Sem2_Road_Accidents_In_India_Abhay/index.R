#1)
#Set this path once for reading excel
p<-"C:/Users/Abhay/Desktop/maths/Maths_Sem2_Road_Accidents_In_India_Abhay/data/"

path_excel<-function(name){
  paste(p,name,sep="")
}
# Read the data into a data frame
accidents <- read_excel(path_excel("gender_maths.xlsx"))
accidents

male_accidents = accidents$male_accidents
female_accidents = accidents$female_accidents

# Conduct t-test to compare male and female accidents
t_test <- t.test(male_accidents, female_accidents)

# Display the t-test results
t_test

#2
accidents<-read_excel(path_excel("gender.xlsx"))

no_of_accidents_in_thousands <- seq.int(0,350,350/(length(accidents$Year)-1))
years <- accidents$Year

plot(years,no_of_accidents_in_thousands,col='white')
points(accidents$Year,accidents$Male,col='red',pch=12)
points(accidents$Year,accidents$Female,col='green',pch=12)

#3
df<-read_excel("state.xlsx")
df

x<-df$`Accidents 2017`
labels<-df$State

pie(x,df$`Share (2017)`,col=rainbow(length(df$`Accidents 2017`)),main='Share in Road Accidents in 2017')
legend("topright",df$State,cex=0.8,fill=rainbow(length(df$`Accidents 2017`)))


x<-df$`2017`
labels<-df$`State Fatalities`

pie(x,df$`F share 2017`,col=rainbow(length(df$`2017`)),main='Contribution to Fatalities')
legend("topright",df$`State Fatalities`,cex=0.8,fill=rainbow(length(df$`Accidents 2017`)))

#4
data <- read.csv(path_excel("RoadAccidentDeaths.csv"))
fit <- lm(Road_Accident_Deaths ~ Age_Group, data = data)
summary(fit)

age_colors <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00", "#FFFF33", "#A65628")

# Plotting the line chart
ggplot(data, aes(x = Year, y = `Road_Accident_Deaths`, color = `Age_Group`, group = `Age_Group`)) +
  geom_line(size = 1.5) +
  labs(x = "Year", y = "Road Accident Deaths", color = "Age Group") +
  scale_color_manual(values = age_colors) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 16, face = "bold"),
    axis.title = element_text(size = 12),
    axis.text = element_text(size = 10),
    legend.title = element_blank(),
    legend.text = element_text(size = 10),
    legend.position = "bottom",
    legend.key.size = unit(1.5, "lines")
  ) +
  ggtitle("Road Accident Deaths in India")

data <- data[data$`Age_Group` != "70", -1]
sums<-colSums(data)
years<-c(2014,2015,2016,2017,2018,2019,2020,2021)
d<-c(0,0,0,0,0,0,0,0)

for (i in 0:8){
  d[i]<-sums[i]+sums[i+1]
} 	
plot(years,d,col='blue')
abline(lm(d~years),cex = 1.3,pch = 16,xlab = "No Of Accidents",ylab = "Year")
