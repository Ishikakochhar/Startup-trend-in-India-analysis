# Run the python Code after installing the following libraries

```
seaborn
pandas
geopandas
```

## The shape folder is required for plotting

<b>| To Run the R Code specify path at the start of the R file in index.js
