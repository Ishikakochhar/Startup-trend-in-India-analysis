import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import geopandas as gpd

sns.set_style('whitegrid')

fp = './shape/india-polygon.shp'
map_df = gpd.read_file(fp)
print(map_df['st_nm'])

df = pd.read_csv('state.csv')
print(df)

merged = map_df.set_index('st_nm').join(df.set_index('States/Uts'))
merged.head()

fig, ax = plt.subplots(1, figsize=(10, 10))
ax.axis('off')
ax.set_title('Deaths due to road accidents in india ', fontdict={'fontsize': '16', 'fontweight' : '10'})

# plot the figure
merged.plot(column='Number of Persons Killed 2015',cmap='YlOrRd', linewidth=0.8, ax=ax, edgecolor='0', legend=True,markersize=[39.739192, -104.990337])
plt.show();